pe ex7: Am observat ca daca dau la GL_TEXTURE_MAG_FILTER pe GL_NEAREST atunci cubul pare mai pixelat fata de cealalta setare in rest GL_TEXTURE_MIN_FILTER  nu am observat daca schimba ceva


